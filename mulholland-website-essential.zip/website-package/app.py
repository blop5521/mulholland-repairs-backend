import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, send_from_directory, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'src', 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app)

def append_to_sheet(sheet_name, data):
    """Simulate appending data to a Google Sheet"""
    print(f"Would append to {sheet_name}: {data}")
    return True

@app.route('/api/forms/repair', methods=['POST'])
def submit_repair_form():
    """Handle repair form submissions"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'description']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Prepare data for Google Sheets
        sheet_data = [
            data.get('name'),
            data.get('email'),
            data.get('phone', ''),
            data.get('description'),
            'Images uploaded' if data.get('images') else 'No images'
        ]
        
        # Append to Google Sheets
        success = append_to_sheet('Repair Requests', sheet_data)
        
        if success:
            return jsonify({'message': 'Repair request submitted successfully'}), 200
        else:
            return jsonify({'error': 'Failed to submit request'}), 500
            
    except Exception as e:
        print(f"Error in repair form submission: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/forms/surfboard-showers', methods=['POST'])
def submit_surfboard_shower_form():
    """Handle surfboard shower form submissions"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'valve', 'shape', 'wood', 'length']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Prepare data for Google Sheets
        sheet_data = [
            data.get('name'),
            data.get('email'),
            data.get('valve'),
            data.get('shape'),
            data.get('wood'),
            f"{data.get('length')}'"
        ]
        
        # Append to Google Sheets
        success = append_to_sheet('Surfboard Shower Orders', sheet_data)
        
        if success:
            return jsonify({'message': 'Surfboard shower order submitted successfully'}), 200
        else:
            return jsonify({'error': 'Failed to submit order'}), 500
            
    except Exception as e:
        print(f"Error in surfboard shower form submission: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/forms/high-voltage-art', methods=['POST'])
def submit_high_voltage_art_form():
    """Handle high voltage art form submissions"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'notes']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Prepare data for Google Sheets
        sheet_data = [
            data.get('name'),
            data.get('email'),
            data.get('phone', ''),
            data.get('notes'),
            'Images uploaded' if data.get('images') else 'No images'
        ]
        
        # Append to Google Sheets
        success = append_to_sheet('High Voltage Art Projects', sheet_data)
        
        if success:
            return jsonify({'message': 'Art project submitted successfully'}), 200
        else:
            return jsonify({'error': 'Failed to submit project'}), 500
            
    except Exception as e:
        print(f"Error in high voltage art form submission: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002, debug=True)

